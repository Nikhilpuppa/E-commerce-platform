#include<bits/stdc++.h>
using namespace std;
#include<iostream>
#ifndef DEMOPORTAL_H
#define DEMOPORTAL_H
#include "Portal.h" 
class DemoPortal {
    public:
    int PortalID = 0;
    //DemoPortal();
    static int RequestID ;
    void processUserCommand(string );
    void checkResponse( );
    void listRequest(string,string );
    void buyRequest(string, int);
    void startRequest();
    //int main();
    //vector<string> split(string);
};
#endif