#include<bits/stdc++.h>
using namespace std;
#ifndef PRODUCT_H
#define PRODUCT_H
class product{
    public:
        string name;
        string rate;
        string quantity;
        product();
        product(string,string,string);
        string get_name();
        string get_rate();
        string get_quantity();
        void Print();
};
#endif
