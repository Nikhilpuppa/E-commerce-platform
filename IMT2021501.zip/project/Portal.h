#ifndef PORTAL_H
#define PORTAL_H
#include<bits/stdc++.h>
using namespace std;
class Portal{
    virtual void processUserCommand(string command);
    virtual void checkResponse();
};
#endif