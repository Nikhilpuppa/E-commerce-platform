#include <bits/stdc++.h>
using namespace std;
#include "product.h"
#ifndef SORT_H
#define SORT_H
class Sort
{
    
    public:                 
    void set_parameter(string parmeter);
    void SortBasedOnParameter(vector<product>products);
    string parameter;
};

#endif