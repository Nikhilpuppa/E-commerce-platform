#include <bits/stdc++.h>
using namespace std;
#include "Sort.h"

void Sort::set_parameter(string p)
{
    parameter = p;
}

bool compare_name(product a,product b)             
{
        return a.get_name() < b.get_name();
}

bool compare_rate(product a,product b)
{
    // cout<<a.get_rate()<<"ra"<<endl;
    // cout<<b.get_rate()<<"rb"<<endl;
    return a.get_rate() < b.get_rate();
}





void Sort::SortBasedOnParameter(vector<product>products)
{
    // for(int i=0;i<products.size();i++){
    //     cout << products[i].get_name()<<"dgh"<<endl;
    // }
    if (parameter == "name")
    {                                              
        sort(products.begin(),products.end(),compare_name);
        for (int i=0;i<products.size();i++)
        {
            products[i].Print();
        }
    }
    else if (parameter == "rate")
    {
        sort(products.begin(),products.end(),compare_rate);
        for (int i=0;i<products.size();i++)
        {
            products[i].Print();
        }
    }
    
}