package demo;

import ecomm.Platform;
import ecomm.Seller;
import ecomm.*;
import java.util.*;

//import javax.lang.model.util.ElementScanner6;
import java.io.FileWriter;   // Import the FileWriter class
import java.io.IOException;
//import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
public class DemoPlatform extends Platform {
	ArrayList<Seller> s= new ArrayList<>();

	@Override
	public boolean addSeller(Seller aSeller) {
		s.add(aSeller);
		return false;
	}

	@Override
	public void processRequests() {

		List<String> lines = Collections.emptyList();  //file  reading
		try{
			lines = Files.readAllLines(Paths.get("portaltoplatform.txt"),StandardCharsets.UTF_8);
		}
		catch (IOException e){
			e.printStackTrace();
		}
		Iterator<String> itr = lines.iterator();
		for(int i=0;i<s.size();i++){
			s.get(i).add_items();
		}
		while(itr.hasNext())  //checking the user input
		{

			//System.out.println(itr.next());
			String str = itr.next();
			String query[] = str.split(" ");
			if(query[2].equals("List"))
			{
				//System.out.println("hhi");
				ListFunc(query[0],query[1],query[3]);
			}
			if(query[2].equals("Buy"))
			{
				BuyFunc(query[0],query[1],query[3],query[4]);
			}
			if(query[2].equals("Start")){
				StartFunc(query[0],query[1]);
			}
		}
	}
	public void ListFunc(String PortalID,String RequestID,String categoryType)  //function for writing the list query
	{
		for(int i=0;i<s.size();i++){
			ArrayList <Product>Selleritems = new ArrayList<Product>();
			Selleritems = s.get(i).get_item();
			for(int j=0;j<Selleritems.size();j++){
				if(Selleritems.get(j).getType().equals(categoryType))
				{
				printliststring(PortalID,RequestID,Selleritems.get(j).getCategory(),Selleritems.get(j).getName(),Selleritems.get(j).getPrice(),Selleritems.get(j).getQuantity());
				}
			}
		}
	}
	public void BuyFunc(String PortalID,String RequestID,String sellerDetails,String qty)  //function for writing the buy query
	{
		int q = Integer.parseInt(qty);
		String partition[] = sellerDetails.split("-");

		for(int i=0;i<s.size();i++)
		{
			if(partition[0].equals(s.get(i).get_name()))
			{
				//System.out.println(partition[1]);
				int res = s.get(i).buy(partition[1],q);
				if(res ==0){
					try {
						FileWriter Writer = new FileWriter("platformtoportal.txt",true);
						Writer.append(PortalID + " " + RequestID  + " " + "Failure\n");
						Writer.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					}
				else
					//System.out.println(PortalID + " " + RequestID  + " " + "Success");
					try {
						FileWriter Writer = new FileWriter("platformtoportal.txt",true);
						Writer.append(PortalID + " " + RequestID  + " " + "Success\n");
						Writer.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
	}
	public void printliststring(String PortalID,String RequestID,Globals.Category ProductName,String productUniqueName,float price,int Quantity){
		// String str = PortalID+" "+RequestID+" ";
		// String str1= " "+productUniqueName+" " +Float.toString(price)+" "+Integer.toString(Quantity);
		// System.out.print(str);
		// System.out.print(ProductName);
		// System.out.println(str1);
		try {
			FileWriter Writer = new FileWriter("platformtoportal.txt",true);
			Writer.append(PortalID + " " + RequestID  + " " +productUniqueName+" " +Float.toString(price)+" "+Integer.toString(Quantity)+"\n");
			Writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void StartFunc(String portalid,String requestid)  //function to write the start query
	{
		int num_books=0;
		int num_mobiles = 0;
		for(int i=0;i<s.size();i++)
		{
			for(int j=0;j<s.get(i).get_item().size();j++)
			{
				if(s.get(i).get_item().get(j).getType() == "Book")
				{
					num_books = num_books + s.get(i).get_item().get(j).getQuantity();
				}
				else{
					num_mobiles = num_mobiles + s.get(i).get_item().get(j).getQuantity();
				}
			}
		}
		//System.out.println(num_books + " " + num_mobiles);
		if(num_books == 0 && num_mobiles!=0){
			//System.out.println(portalid + " "+ requestid + " " + "Mobile");
			try {
				FileWriter Writer = new FileWriter("platformtoportal.txt",true);
				Writer.append(portalid + " "+ requestid + " " + "Mobile");;
				Writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(num_books !=0 && num_mobiles == 0){
			try {
				FileWriter Writer = new FileWriter("platformtoportal.txt",true);
				Writer.append(portalid + " "+ requestid + " " + "Book"+"\n");;
				Writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			//System.out.println(portalid + " " + requestid + " "+ "Book");
		else if(num_books == 0 && num_mobiles == 0){
			try {
				FileWriter Writer = new FileWriter("platformtoportal.txt",true);
				Writer.append(portalid + " "+ requestid+"\n");;
				Writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			//System.out.println(portalid + " " + requestid);
		else
		{
			try {
				FileWriter Writer = new FileWriter("platformtoportal.txt",true);
				Writer.append(portalid + " "+ requestid + " " + "Book"+" "+"Mobile"+"\n");;
				Writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			//System.out.println(portalid + " "+ requestid + " " + "Book" + " " + "Mobile");
		
	}

}
