package ecomm;
import java.util.*;

import java.util.ArrayList;

public abstract class Seller {
    ArrayList<Seller>Sellers = new ArrayList<>();
    public abstract int buy(String category,int qty);
    public abstract int num_books();
    public abstract int num_moblies();
    public abstract ArrayList<Product> get_item();
    public abstract void add_items();
    public abstract String  get_name();
    //public abstract String get_Category(String uniqueName);
    //public void addPlatform(Platform );
}
