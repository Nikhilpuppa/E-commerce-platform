package Sellers;
import ecomm.*;
public class Book extends Product{
    String name;
    String productid;
    int quantity;
    float price;
    Book(String name,String productid,int quantity,float price){
        this.name=name;
        this.productid=productid;
        this.quantity=quantity;
        this.price=price;
    }
    public Globals.Category getCategory()        //returns category
    {
        return Globals.Category.Book;
    }
    public String getName(){       //returns name
        return this.name;
    }
    public String getProductID(){        //returns productid
        return this.productid;
    }
    public float getPrice(){      //returns price
        return this.price;
    }
    public int getQuantity(){        //returns quantity
        return this.quantity;
    }
    public String getType()        //returns type
    {
        return "Book";
    }
    public void setQuantity(int x)       //sets the qunatity
    {
        this.quantity = x;
    }
}