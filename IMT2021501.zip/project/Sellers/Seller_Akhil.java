package Sellers;
import java.util.*;
import ecomm.*;
public class Seller_Akhil extends Seller{
    String name;
    int num_b = 2;
    int num_m = 1;
    ArrayList<Product> Akhil_items = new ArrayList<Product>();
    Book b1 = new Book("Book1","134",3,300);
    Book b2 = new Book("Book2","124",3,400);
    Mobile m1 = new Mobile("Mobile1","210",2,4000);
    public Seller_Akhil(String name)
    {
        this.name = name;
    }
    public String get_name()           //returns name
    {
        return this.name;
    }
    public int num_books()            //returns number of books
    {
        return num_b;
    }
    public int num_moblies()         //returns number of mobiles
    {
        return num_m;
    }
    public int buy(String category,int qty)   //logic for buy query
    {
        for(int i=0;i<Akhil_items.size();i++){
            if(Akhil_items.get(i).getName().equals(category))
            {
                if(Akhil_items.get(i).getQuantity()>=qty){
                    Akhil_items.get(i).setQuantity(Akhil_items.get(i).getQuantity()-qty);
                    return 1;
                }
            }
        }
        return 0;
    }
    public void add_items(){          //contains all the items
        Akhil_items.add(b1);
        Akhil_items.add(b2);
        Akhil_items.add(m1);
    }
    public ArrayList<Product> get_item(){

        return Akhil_items;
    }


}
