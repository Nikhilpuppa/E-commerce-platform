package Sellers;
import java.util.*;
import ecomm.*;
public class Seller_Nikhil extends Seller{
    String name;
    int num_b = 1;
    int num_m = 1;
    ArrayList <Product> Nikhil_items= new ArrayList<Product>();
    Book b3 = new Book("Book3","144",7,500);
    Mobile m1 = new Mobile("Mobile1","210",9,7000);
    public Seller_Nikhil(String name)
    {
        this.name = name;
    }
    public int num_books()             //returns number of books
    {
        return num_b;
    }
    public String get_name()             //returns name
    {
        return this.name;
    }
    public int num_moblies()        //returns number of moblies
    {
        return num_m;
    }
    public int buy(String category,int qty)        //logic for buy query
    {
        for(int i=0;i<Nikhil_items.size();i++){
            if(Nikhil_items.get(i).getName().equals(category))
            {
                if(Nikhil_items.get(i).getQuantity()>=qty){
                    Nikhil_items.get(i).setQuantity(Nikhil_items.get(i).getQuantity()-qty);
                    return 1;
                }
            }
        }
        return 0;
    }
    public void add_items(){             //contains all the items
        Nikhil_items.add(b3);
        Nikhil_items.add(m1);
    }
    public ArrayList<Product> get_item(){

        return Nikhil_items;
    }
}
