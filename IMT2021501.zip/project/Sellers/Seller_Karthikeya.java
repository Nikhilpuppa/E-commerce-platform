package Sellers;
import java.util.*;
import ecomm.*;
public class Seller_Karthikeya extends Seller{
    String name;
    int num_b = 1;
    int num_m = 2;
    ArrayList <Product> Karthikeya_items= new ArrayList<Product>();
    Book b1 = new Book("Book1","134",2,600);
    Mobile m1 = new Mobile("Mobile1","210",1,9000);
    Mobile m2 = new Mobile("Mobile2","220",7,1000);
    public Seller_Karthikeya(String name)
    {
        this.name = name;
    }
    public String get_name()               //returns name
    {
        return this.name;
    } 
    public int num_books()             //returns number of books
    {
        return num_b;
    }
    public int num_moblies()          //returns number of mobiles
    {
        return num_m;
    }
    public int buy(String category,int qty)       //logic for buy query
    {
        for(int i=0;i<Karthikeya_items.size();i++){
            if(Karthikeya_items.get(i).getName().equals(category))
            {
                if(Karthikeya_items.get(i).getQuantity()>=qty){
                    Karthikeya_items.get(i).setQuantity(Karthikeya_items.get(i).getQuantity()-qty);
                    return 1;
                }
            }
        }
        return 0;
    }
    public void add_items(){              //contains all the items
        Karthikeya_items.add(b1);
        Karthikeya_items.add(m1);
        Karthikeya_items.add(m2);
    }
    public ArrayList<Product> get_item(){


        return Karthikeya_items;
    }
}
