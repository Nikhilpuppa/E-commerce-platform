package Sellers;
import ecomm.*;
public class Mobile extends Product{
    String name;
    String productid;
    int quantity;
    float price;
    Mobile(String name,String productid,int quantity,float price){
        this.name=name;
        this.productid=productid;
        this.quantity=quantity;
        this.price=price;
    }
    public Globals.Category getCategory()        //returns category
    {
        return Globals.Category.Mobile;
    }
    public String getName(){        //returns name
        return name;
    }
    public String getProductID(){        //returns productid
        return productid;
    }
    public float getPrice(){         //returns price
        return price;
    }
    public int getQuantity(){      //returns quantity
        return quantity;
    }
    public String getType(){        //returns type
        return "Mobile";
    }
    public void setQuantity(int x)       //sets the qunatity
    {
        this.quantity = x;
    } 
}
