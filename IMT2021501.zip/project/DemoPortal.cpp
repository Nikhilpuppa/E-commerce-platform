#include<bits/stdc++.h>
using namespace std;
#include<fstream>
#include "DemoPortal.h"
ofstream outdata; 
#include "product.h"
#include "Sort.h"
vector<string> sortTypes;
vector<string> u;
void DemoPortal::processUserCommand(string command){    //takes inputs

            if(command == "Buy")
            {
                string sname;
                cin>>sname;
                int numitems;
                cin>>numitems;
                DemoPortal p;
                p.buyRequest(sname,numitems);
            }
            if(command== "List")
            {
                string categoryType;
                cin >> categoryType;
                string sortType;
                cin>>sortType;
                //cout<<sortType;
                sortTypes.push_back(sortType);
                DemoPortal p;
                p.listRequest(categoryType,sortType); 

            }
            if(command == "Start")
            {
                DemoPortal p;
                p.startRequest();
            }
                    //     for(int i=0;i<sortTypes.size();i++){
                    // cout<<sortTypes[i];
                    // }
        }


int DemoPortal::RequestID=0;
vector<string> split(string s)         //splits a sentence based on spaces
{ 
    int i,j=0;
    vector<string> str;
    for(i=0;i<s.length();i++)
    {
        if(s[i] == ' ')
        {
            str.push_back(s.substr(j,i-j));
            j=i+1;
        }
        else if(i== s.length()-1)
        {
            str.push_back(s.substr(j,i-j+1));
        }
    }
    return str;
}
void listCall(vector<string> list,string sortType)
{
    vector<product> prs;
        Sort s;
        //cout<<sortTypes[i];
        s.set_parameter(sortType);

        for(int j=0;j<list.size();j++)
        {
            vector<string> s = split(list[j]);
            product p(s[2],s[3],s[4]);
            prs.push_back(p);
        }
        s.SortBasedOnParameter(prs);
        //prs.clear();
}
void DemoPortal::listRequest(string ct,string s)         //for list query
{
    PortalID++;
    RequestID++;
    cout<<PortalID<<" "<<RequestID<<" "<<"List"<<" "<<ct<<endl;
    outdata<<PortalID<<" "<<RequestID<<" "<<"List"<<" "<<ct<<endl;
    //out=to_string(PortalID)+" " +to_string(RequestID)+" "+"List"+" "+s;

}
void DemoPortal::buyRequest(string st,int qty)            //for buy query
{
    PortalID++;
    RequestID++;
    cout<<PortalID<<" "<<RequestID<<" "<<"Buy"<<" "<<st<<" "<<qty<<endl;
    //outdata.open("portaltoplatform.txt");
    outdata<<PortalID<<" "<<RequestID<<" "<<"Buy"<<" "<<st<<" "<<qty<<endl;

}
void DemoPortal::startRequest()            //for start query
{
    PortalID++;
    RequestID++;
    cout<<PortalID<<" "<<RequestID<<" "<<"Start"<<endl;
    outdata<<PortalID<<" "<<RequestID<<" "<<"Start"<<endl;

}
void DemoPortal::checkResponse()         //takes in the file platformtoportal and satisfies the query 
{
    ifstream fin;
    fin.open("platformtoportal.txt");
    string line;
    string l;
    vector<vector<string>> list1;
    vector<string> list2;
    int i=0;
    int current_requestid;
    while(getline(fin,l)){
        vector<string> lf = split(l);
        if(lf.size()==5)
        {
            current_requestid = stoi(lf[1]);
            break;
        }

    }
    vector<string> lf = split(l);
    ifstream fin1;
    fin1.open("platformtoportal.txt");
    while(getline(fin1,line)){            //iterating throught the file and calling the respective functions based on the query
         vector<string> l = split(line);
        if(l.size()==4 && l[0] != "Check")
        {
            cout<<l[2]<<" "<<l[3]<<endl;    
        }
        else if((l[2] == "Success") || (l[2] == "Failure")&&l[0] != "Check"){
            cout<<l[2]<<endl;
        }
        else if(l.size() == 5){
        {
            if(current_requestid == stoi(l[1]) ){
                list2.push_back(line);
                }
            else
            {
                current_requestid = stoi(l[1]);
                list1.push_back(list2);
                listCall(list2,sortTypes[i]);
                i++;
                list2.clear();
                list2.push_back(line);

            }
        }
    }
    }
    list1.push_back(list2);
    listCall(list2,sortTypes[i-1]);
    vector<product> prs;
}
int main()
{
    string str;
    outdata.open("portaltoplatform.txt");
    DemoPortal pr;
    while(true)
    {
        cin>>str;
        if(str=="End"){            //terminates the program
            outdata.close();
            break;
        }
        else if(str=="Check"){         //if check is typed by user it calls checkresponse
            pr.checkResponse();
        }
        else{
            pr.processUserCommand(str);        // else it calls processusercommand function
        } 

    }
}