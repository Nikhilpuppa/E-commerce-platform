#include<bits/stdc++.h>
using namespace std;
#include "product.h"

product::product(string name,string rate,string quantity){
    this->name=name;
    this->quantity=quantity;
    this->rate=rate;
}
string product::get_name(){ 
    return this->name;
}
string product::get_rate(){
    return this->rate;
}
string product::get_quantity(){
    return this->quantity;
}
void product::Print(){
    cout << this->name << " " << this->quantity << " " << this->rate << endl;
}
