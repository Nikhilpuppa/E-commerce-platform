import demo.DemoPlatform;
import ecomm.Platform;
import ecomm.Seller;
import Sellers.*;
import java.util.*;
public class PlatformMain {

	public static void main(String[] args) {      //inputs

		Platform pf = new DemoPlatform(); 
		Scanner sc = new Scanner(System.in);
                 // replace with appropriate derived class
		
		// create a number of sellers (of different sub-types of Seller)
		// Assign a name (sellerID) to each of them.
		
		// replace each of the XYZ below with the derived class name of one of the
		// team members.		
		
		Seller s1 = new Seller_Akhil("Akhil");
		//s1.addPlatform(pf);
		pf.addSeller(s1);

		Seller s2 = new Seller_Karthikeya("Karthikeya");
		//s2.addPlatform(pf);
		pf.addSeller(s2);
		
		Seller s3 = new Seller_Nikhil("Nikhil");
		//s3.addPlatform(pf);
		pf.addSeller(s3);
 		while(true){
		String input= sc.next();
		if(input.equals("Check"))
		{
			pf.processRequests();
		}}

			
	}

}
